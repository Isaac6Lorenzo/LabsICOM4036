All repositories in these organizations:

* [lightbend](https://github.com/lightbend)
* [akka](https://github.com/akka)
* [lagom](https://github.com/lagom)
* [playframework](https://github.com/playframework)
* [sbt](https://github.com/sbt)
* [slick](https://github.com/slick)

are covered by the Lightbend Community Code of Conduct: https://www.lightbend.com/conduct

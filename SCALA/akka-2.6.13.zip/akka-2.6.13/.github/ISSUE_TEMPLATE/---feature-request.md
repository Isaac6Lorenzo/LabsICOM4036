---
name: "\U0001F389 Feature request"
about: Suggest an idea for this project

---

<!--
Please report issues regarding specific projects in their respective issue trackers, e.g.:
 - Akka HTTP: https://github.com/akka/akka-http/issues
 - Alpakka:   https://github.com/akka/alpakka/issues
 - Akka Persistence Cassandra Plugin: https://github.com/akka/akka-persistence-cassandra/issues
 - ...

Please explain your use case precisely, and if possible provide an example snippet.

Thanks, happy hakking!
-->

---
name: "\U0001F41B Bug report"
about: Create a report to help us improve

---

<!--
Please report issues regarding specific projects in their respective issue trackers, e.g.:
 - Akka HTTP: https://github.com/akka/akka-http/issues
 - Alpakka:   https://github.com/akka/alpakka/issues
 - Akka Persistence Cassandra Plugin: https://github.com/akka/akka-persistence-cassandra/issues
 - ...

Please explain your issue precisely, and if possible provide a reproducer snippet (this helps resolve issues much quicker).

Thanks, happy hakking!
-->

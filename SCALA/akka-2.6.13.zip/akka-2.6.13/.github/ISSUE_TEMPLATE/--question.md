---
name: "❓ Question"
about: Please use https://discuss.akka.io for questions

---

Please use https://discuss.akka.io for questions instead of posting them to the issue tracker.
